import { useState } from 'react'
import './App.css'

const cards = [
  {
    question: "What is Newton's Second Law?",
    answer: "The acceleration of an object as produced by a net force is directly proportional to the magnitude of the net force, in the same direction as the net force, and inversely proportional to the mass of the object.\n\nFormula: F = ma"
  },
  {
    question: "What is the speed of light in a vacuum?",
    answer: "The speed of light in a vacuum is a universal physical constant important in many areas of physics.\n\nValue: c ≈ 3.00 × 10⁸ m/s"
  },
  {
    question: "What is the formula for Kinetic Energy?",
    answer: "Kinetic energy is the energy that an object possesses due to its motion.\n\nFormula: KE = ½mv²"
  },
  {
    question: "What is Archimedes' Principle?",
    answer: "Any object, wholly or partially immersed in a fluid, is buoyed up by a force equal to the weight of the fluid displaced by the object."
  },
  {
    question: "What is the First Law of Thermodynamics?",
    answer: "Energy can be converted from one form to another with the interaction of heat, work and internal energy, but it cannot be created nor destroyed.\n\nFormula: ΔU = Q - W"
  }
];

function App() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % cards.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + cards.length) % cards.length);
  };

  const toggleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <h1 className="text-3xl font-bold text-slate-800 mb-8">Physics Flashcards</h1>
      
      <div className="w-full max-w-md h-64 perspective-1000 cursor-pointer" onClick={toggleFlip}>
        <div className={`relative w-full h-full transition-transform duration-500 preserve-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
          {/* Front */}
          <div className="absolute w-full h-full bg-white rounded-xl shadow-lg flex flex-col items-center justify-center p-8 backface-hidden border border-slate-200">
            <span className="text-sm font-semibold text-slate-400 mb-4 uppercase tracking-wider">Question</span>
            <p className="text-xl text-center font-medium text-slate-700">{cards[currentIndex].question}</p>
          </div>
          
          {/* Back */}
          <div className="absolute w-full h-full bg-blue-50 rounded-xl shadow-lg flex flex-col items-center justify-center p-8 backface-hidden rotate-y-180 border border-blue-100">
            <span className="text-sm font-semibold text-blue-400 mb-4 uppercase tracking-wider">Answer</span>
            <p className="text-lg text-center text-slate-700 whitespace-pre-line">{cards[currentIndex].answer}</p>
          </div>
        </div>
      </div>

      <div className="mt-8 flex flex-col items-center gap-4">
        <p className="text-slate-500 font-medium">
          {currentIndex + 1} of {cards.length}
        </p>
        
        <div className="flex gap-4">
          <button 
            onClick={(e) => { e.stopPropagation(); handlePrev(); }}
            className="px-6 py-2 bg-white border border-slate-300 text-slate-600 rounded-lg hover:bg-slate-50 transition-colors font-medium"
          >
            Previous
          </button>
          <button 
            onClick={(e) => { e.stopPropagation(); handleNext(); }}
            className="px-6 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors font-medium"
          >
            Next
          </button>
        </div>
      </div>

      <p className="mt-12 text-slate-400 text-sm">Click the card to flip</p>
    </div>
  )
}

export default App
